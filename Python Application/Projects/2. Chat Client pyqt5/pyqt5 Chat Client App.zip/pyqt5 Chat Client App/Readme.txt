Usage

(1) First click the server executable file.
(2) Then type your userame.
(3) This time click the client executable file.
(4) Again need to type your userame.
(5) Now you can message through a pipeline.

Green color means send message and Blue color mean recieved message.